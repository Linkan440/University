-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2022 at 02:46 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cseproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `adpass`
--

CREATE TABLE `adpass` (
  `ID` varchar(30) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adpass`
--

INSERT INTO `adpass` (`ID`, `Password`) VALUES
('2021038010', '123456'),
('202010', '456789'),
('000002', 'asdfgh'),
('45213', 'storm');

-- --------------------------------------------------------

--
-- Table structure for table `adsresult`
--

CREATE TABLE `adsresult` (
  `StudentID` varchar(30) NOT NULL,
  `Year` varchar(30) NOT NULL,
  `Semester` varchar(30) NOT NULL,
  `Credit` varchar(30) NOT NULL,
  `CGPA` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adsresult`
--

INSERT INTO `adsresult` (`StudentID`, `Year`, `Semester`, `Credit`, `CGPA`) VALUES
('2037010', 'First', 'First', '6.00', '3.54'),
('20201038010', 'Second', 'Third', '6.00', '3.75');

-- --------------------------------------------------------

--
-- Table structure for table `adstinfo`
--

CREATE TABLE `adstinfo` (
  `StudentID` varchar(30) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `FatherName` varchar(30) NOT NULL,
  `MotherName` varchar(30) NOT NULL,
  `Blood` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Mobile` varchar(30) NOT NULL,
  `GuardianMobile` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `DateOfBirth` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adstinfo`
--

INSERT INTO `adstinfo` (`StudentID`, `Name`, `FatherName`, `MotherName`, `Blood`, `Address`, `Mobile`, `GuardianMobile`, `Email`, `DateOfBirth`) VALUES
('20201038010', 'Akash', 'Shahidul Islam', 'Shahana Islam', 'A+', 'khulna', '018888', '014444', 's@gmail.com', '16 July,1999'),
('20201037010', 'Sajib', 'Manash Datta', 'Ratna Datta', 'AB+', 'Khulna', '01999', '01444', 'i@gmail.com', ''),
('20201060010', 'Linkan Roy', 'Nittanando Roy', 'Anjoli Roy', 'B+', 'Khulna', '198889', '175555', 'l@gmail.com', '19 may,1999');

-- --------------------------------------------------------

--
-- Table structure for table `adstregister`
--

CREATE TABLE `adstregister` (
  `ID` varchar(30) NOT NULL,
  `Year` varchar(30) NOT NULL,
  `Semester` varchar(30) NOT NULL,
  `Type` varchar(30) NOT NULL,
  `Approval` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adstregister`
--

INSERT INTO `adstregister` (`ID`, `Year`, `Semester`, `Type`, `Approval`) VALUES
('20201037010', 'First', 'First', 'Tri-semester', 'Approved'),
('20201038010', 'Second', 'First', 'Tri-semester', 'Approved'),
('20201060010', 'Second', 'Third', 'Tri-semester', 'Approved'),
('202010211010', 'Second', 'Second', 'Tri-semester', 'Approved'),
('20201021010', 'First', 'Second', 'Tri-semester', ''),
('202010421010', 'First', 'Third', 'Tri-semester', '');

-- --------------------------------------------------------

--
-- Table structure for table `adteinfo`
--

CREATE TABLE `adteinfo` (
  `Name` varchar(30) NOT NULL,
  `Id` varchar(30) NOT NULL,
  `Pay` varchar(30) NOT NULL,
  `Department` varchar(30) NOT NULL,
  `Position` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Mobile` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `adteinfo`
--

INSERT INTO `adteinfo` (`Name`, `Id`, `Pay`, `Department`, `Position`, `Address`, `Mobile`, `Email`) VALUES
('Shafik Alam', '1234', '75000', 'EEE', 'Senior Lecturer', 'Khulna', '017888', 'al@gmail.com'),
('Alam Roy', '038010', '55000', 'CSE', 'Lecturer', 'Khulna', '0199000', 'alam@gmail.com'),
('Alamin Islam ', '3455', '85000', 'EEE', 'Senior Lecturer', 'Khulna', '017899', 'ala@gmail.com'),
('Mamun Haque', '45678', '65000', 'CSE', 'Lecturer', 'Khulna', '01666', 'm@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `semester_courses`
--

CREATE TABLE `semester_courses` (
  `Year` varchar(30) NOT NULL,
  `Semester` varchar(30) NOT NULL,
  `Type` varchar(30) NOT NULL,
  `CourseCode` varchar(30) NOT NULL,
  `Title` varchar(30) NOT NULL,
  `Credit` varchar(30) NOT NULL,
  `Remark` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `semester_courses`
--

INSERT INTO `semester_courses` (`Year`, `Semester`, `Type`, `CourseCode`, `Title`, `Credit`, `Remark`) VALUES
('First', 'First', 'Tri-semester', 'CSE-1101', 'Object Oriented Programming', '3.00', 'Regular'),
('First', 'First', 'Tri-semester', 'Math-1131', 'Mathematics-II', '3.00', 'Regular'),
('First', 'Second', 'Tri-semester', 'CSE-1201', 'Digital Logic Design ', '3.00', 'Regular'),
('First', 'Second', 'Tri-semester', 'EEE-1221', 'Electrical Circuits', '3.00', 'Regular'),
('First', 'Third', 'Tri-semester', 'CSE-1301', 'Algorithm', '3.00', 'Regular'),
('First', 'Third', 'Tri-semester', 'Math-1331', 'Mathematics-III', '3.00', 'Regular'),
('Second', 'First', 'Tri-semester', 'CSE-2101', 'Data Structures ', '3.00', 'Regular'),
('Second', 'First', 'Tri-semester', 'EEE-1221', ' Electronic Devices and Circui', '3.00', 'Regular'),
('First', 'Third', 'Tri-semester', 'CSE-1301', 'Algorithm', '3.00', 'Regular'),
('First', 'Third', 'Tri-semester', 'Math-1331', 'Mathematics-III', '3.00', 'Regular'),
('Second', 'First', 'Tri-semester', 'CSE-2101', 'Data Structures ', '3.00', 'Regular'),
('Second', 'First', 'Tri-semester', 'EEE-1221', ' Electronic Devices and Circui', '3.00', 'Regular'),
('Second', 'Second', 'Tri-semester', 'CSE-2201', 'Applied Probability and Queuin', '3.00', 'Regular'),
('Second', 'Second', 'Tri-semester', 'Math-2231', 'Mathematics-IV', '3.00', 'Regular'),
('Second', 'Third', 'Tri-semester', 'CSE-2301', 'Microprocessors and Microcompu', '3.00', 'Regular'),
('Second', 'Third', 'Tri-semester', 'PHY-2305', 'Physics-I', '3.00', 'Regular');

-- --------------------------------------------------------

--
-- Table structure for table `stpass`
--

CREATE TABLE `stpass` (
  `id` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stpass`
--

INSERT INTO `stpass` (`id`, `password`) VALUES
('Akash', '12345678'),
('Linkan', '456123');

-- --------------------------------------------------------

--
-- Table structure for table `teaclass`
--

CREATE TABLE `teaclass` (
  `CourseCode` varchar(30) NOT NULL,
  `Title` varchar(30) NOT NULL,
  `Room` varchar(30) NOT NULL,
  `Time` varchar(30) NOT NULL,
  `TeacherID` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teaclass`
--

INSERT INTO `teaclass` (`CourseCode`, `Title`, `Room`, `Time`, `TeacherID`) VALUES
('CSE-3201', 'Data Structures', 'R-302', '8.30-9.15 am', '038010'),
('CSE-2301', 'Algorithms', 'R-502', '9.30-10.45 am', '038010'),
('CSE-4203', 'Computer Networks', 'R-506', '11.00-12.15 am', '038010'),
('CSE-2101', 'OOP', 'R-402', '12.30-1.45 pm', '038010'),
('EEE-4121', 'Electrical Circuits', 'R-509', '8.30-9.15 am', '1234'),
('EEE-1221', ' Electronic Devices and Circui', 'R-409', '9.30-10.45 am', '1234'),
('EEE-3121', 'Electrical Technology', 'R-301', '11.00-12.15 pm', '1234'),
('EEE-2221', 'Digital Electronics and Pulse ', 'R-702', '12.30-1.45 pm', '1234'),
('CSE-1105', 'Microproccesors', 'R-703', '2.00-3.15 pm', '038010'),
('PHY-4134', 'Physics-IV', 'R-603', '9.15-10.30 pm', '45678');

-- --------------------------------------------------------

--
-- Table structure for table `tepass`
--

CREATE TABLE `tepass` (
  `id` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tepass`
--

INSERT INTO `tepass` (`id`, `password`) VALUES
('Ismail rahman', '123450'),
('Amar roy', '789456');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
